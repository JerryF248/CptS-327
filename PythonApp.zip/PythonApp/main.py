# <copyright file="main.py" company = "Jerry Fregoso"Copyright (c). All rights reserved. </copyright>

import sqlite3
from tkinter import *
import customtkinter
import onetimepass as otp
from secrets import choice
import smtplib
import re

root = customtkinter.CTk()
root.title("Workout App")
width = 1100
height = 600
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width/2) - (width/2)
y = (screen_height/2) - (height/2)
root.geometry("%dx%d+%d+%d" % (width, height, x, y))
root.resizable(0, 0)

#==============================METHODS========================================
def generate_secret():  # Function to return a random string with length 16.
    secret = ''
    while len(secret) < 16:
        secret += choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ234567')
    return secret

def Database():
    global conn, cursor
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS `member` (mem_id INTEGER NOT NULL PRIMARY KEY  AUTOINCREMENT, username TEXT, password TEXT)")      
    cursor.execute("CREATE TABLE IF NOT EXISTS `workouts` (name TEXT, muscle TEXT, equipment TEXT)")    
    # workout1 = ["pushups", "chest", "none"]
    # workout2 = ["squats", "legs", "squat rack"]
    # workout3 = ["curls", "biceps", "dumbells"]
    # cursor.execute("insert into workouts(name, muscle, equipment) values(?,?,?)", workout1)
    # cursor.execute("insert into workouts(name, muscle, equipment) values(?,?,?)", workout2)
    # cursor.execute("insert into workouts(name, muscle, equipment) values(?,?,?)", workout3)
    # conn.commit()
   
def Login(event=None):
    Database()
    if USERNAME.get() == "" or PASSWORD.get() == "":
        labelText.configure(text="Please complete the required field!", fg_color="red")
    else:
        cursor.execute("SELECT * FROM `member` WHERE `username` = ? AND `password` = ?", (USERNAME.get(), PASSWORD.get()))
        if cursor.fetchone() is not None:
            #HomeWindow()
            TwoFA()
            USERNAME.set("")
            PASSWORD.set("")
            labelText.configure(text="")
        else:
            labelText.configure(text="Invalid username or password", fg_color="red")
            USERNAME.set("")
            PASSWORD.set("")  
    cursor.close()
    conn.close()

def Register(event=None):
    global RegisterPage
    root.withdraw()
    RegisterPage = customtkinter.CTkToplevel(root)
    RegisterPage.title("Workout App")
    width = 1100
    height = 600
    root.resizable(0, 0)
    RegisterPage.geometry("%dx%d" % (width, height))
    #==============================LABELS=========================================
    labelTitle = customtkinter.CTkLabel(RegisterPage, text = "Register", font=('arial', 15))
    labelTitle.grid(row = 0)
    labelUsername = customtkinter.CTkLabel(RegisterPage, text= "Username:", font=('arial', 14))
    labelUsername.grid(row=1, sticky="e")
    labelPassword = customtkinter.CTkLabel(RegisterPage, text= "Password:", font=('arial', 14))
    labelPassword.grid(row=2, sticky="e")
    labelText = customtkinter.CTkLabel(RegisterPage, text = "")
    labelText.grid(row=3, columnspan=2)

    #==============================ENTRY WIDGETS==================================
    username = Entry(RegisterPage, textvariable=USERNAME, font=(14))
    username.grid(row=1, column=1)
    password = Entry(RegisterPage, textvariable=PASSWORD, font=(14))
    password.grid(row=2, column=1)

    #==============================BUTTON WIDGETS=================================
    registerButton = customtkinter.CTkButton(RegisterPage, text="Register", width=45, command=RegisterUser)
    registerButton.grid(row=5, columnspan=2)
    backButton = customtkinter.CTkButton(RegisterPage, text='Back', command=RegisterBack)
    backButton.grid(row = 1, column = 3)
#==============================REGISTER USER==================================
def RegisterUser(event=None):
    Database()
    cursor.execute("SELECT * FROM `member` WHERE `username` = ? AND `password` = ?", (USERNAME.get(), PASSWORD.get()))
    if USERNAME.get() == "" or PASSWORD.get() == "":
        labelText.configure(text="Please complete the required field!", fg_color="red")
    else:
        cursor.execute("SELECT * FROM `member` WHERE `username` = ? AND `password` = ?", (USERNAME.get(), PASSWORD.get()))
        if cursor.fetchone() is not None:
            labelText.configure(text="")
            labelText.configure(text="User already exists!", fg_color="red")
            USERNAME.set("")
            PASSWORD.set("")  
        else:
            sql = ''' INSERT INTO `member` (username, password) VALUES(?,? )'''
            cursor.execute(sql,(USERNAME.get(),PASSWORD.get()))
            conn.commit()
            USERNAME.set("")
            PASSWORD.set("")
            RegisterBack()
    cursor.close()
    conn.close()

#==============================WORKOUTS=================================
def Workout(event=None):
    Database()
    global WorkoutPage
    Home.destroy()
    WorkoutPage = customtkinter.CTkToplevel(root)
    WorkoutPage.title("Workout App")
    width = 1100
    height = 600
    root.resizable(0, 0)
    WorkoutPage.geometry("%dx%d" % (width, height))

    #==============================DATA===========================================
    nameText = customtkinter.CTkLabel(WorkoutPage, text = "name")
    nameText.grid(row=1, column=0)
    muscleText = customtkinter.CTkLabel(WorkoutPage, text = "muscle ")
    muscleText.grid(row=1, column=1)
    equipmentText = customtkinter.CTkLabel(WorkoutPage, text = "equipment")
    equipmentText.grid(row=1, column=2)

    result = cursor.execute("SELECT * FROM `workouts`").fetchall()
    values = re.findall('(?<=\')([^.]*?)(?=\')', str(result))
    workoutLabels = [customtkinter.CTkLabel(master=WorkoutPage, text=values[r]) for r in range(0,len(values)) if r%2 == 0]
    r = 0
    while r in range(0,len(workoutLabels)):
        workoutLabels[r].grid(row=2+r, column = 0)
        workoutLabels[r+1].grid(row=2+r, column = 1)
        workoutLabels[r+2].grid(row=2+r, column = 2)
        r+=3

    #==============================LABELS=========================================
    labelText = customtkinter.CTkLabel(WorkoutPage, text = "")
    labelText.grid(row=3, columnspan=2)

    #==============================BUTTONS=========================================
    backButton = customtkinter.CTkButton(WorkoutPage, text='Back', command=WorkoutBack)
    backButton.grid(row = 0, column = 3)


def TwoFA():
    # ------------------- Create Page -----------------------
    global middlePage
    root.withdraw()
    middlePage = customtkinter.CTkToplevel(root)
    middlePage.title("Workout App")
    width = 1100
    height = 600
    root.resizable(0, 0)
    middlePage.geometry("%dx%d" % (width, height))

    # ------------------- Generate secret and token ----------
    secret = generate_secret()
    token = otp.get_hotp(secret, intervals_no=3)

    # ------------------- Email token -----------------------
    server = smtplib.SMTP('smtp.gmail.com',587)
    server.starttls()
    server.login('fregosojerry327@gmail.com', 'vuzmrlzbbqfrhtim')
    message = str(token)
    server.sendmail('fregosojerry327@gmail.com', 'jerry_fregoso@yahoo.com', message)

    # ------------------- Labels and Entries-----------------------
    middlePageLabel = customtkinter.CTkLabel(middlePage, text=("Enter the following secret in your authenticator app: %s", secret))
    instructionsLabel = customtkinter.CTkLabel(middlePage, text=("Check your email for the token"))
    middlePageLabel.grid(row=0, column=0)
    instructionsLabel.grid(row=1, column = 0)
    labelCode = customtkinter.CTkLabel(middlePage, text= "Code:", font=('arial', 14))
    labelCode.grid(row=2,column = 0, sticky="e")
    middlePageText = customtkinter.CTkLabel(middlePage, text = "")
    middlePageText.grid(row=3, columnspan=2, pady = 350)
    code = Entry(middlePage, textvariable=CODE, font=(14))
    code.grid(row=2, column=1)

    # ------------------- Email authentication -----------------------
    def SecondLogin():
        counter = 0
        if CODE.get() == "":
            middlePageText.configure(text="Please complete the required field!", fg_color="red")
        else:
            authenticated = otp.valid_hotp(CODE.get(), secret, counter)
            if authenticated:
                HomeWindow()
                CODE.set("")
                middlePageText.configure(text="")
                counter += 1
            else:
                middlePageText.configure(text="Invalid code", fg_color="red")
                CODE.set("")

    # ------------------- Buttons -----------------------
    verifyButton = customtkinter.CTkButton(middlePage, text="Verify", width=45, command=SecondLogin)
    verifyButton.grid(pady=25, row=2,column =3, columnspan=2)
    verifyButton.bind('<Return>', SecondLogin)
    SecondLogin()
    backOneButton = customtkinter.CTkButton(middlePage, text='Back', command=VerifyBack)
    backOneButton.grid(row = 0, column = 1, sticky = "e")

def HomeWindow():
    #==============================HOME PAGE======================================
    global Home
    root.withdraw()
    Home = customtkinter.CTkToplevel(root)
    Home.title("Workout App")
    width = 1100
    height = 600
    root.resizable(0, 0)
    Home.geometry("%dx%d" % (width, height))

    #==============================LABELS======================================
    homeLabel = customtkinter.CTkLabel(Home, text=("Welcome to WorkoutWorld ", USERNAME.get(), "!"), font=('arial', 15))
    homeLabel.grid(row=0, column=0)

    #==============================BUTTONS======================================
    backButton = customtkinter.CTkButton(Home, text='Logout', command=HomeBack)
    backButton.grid(row = 0, column = 1, columnspan=5)
    workoutButton = customtkinter.CTkButton(Home, text="Workouts", command = Workout)
    workoutButton.grid(row=2, column=0, columnspan=10, rowspan=2)
    videoButton = customtkinter.CTkButton(Home, text="Videos", command = Workout)
    videoButton.grid(row=4, column=0, columnspan=10, rowspan=2)
    mealsButton = customtkinter.CTkButton(Home, text="Meals", command = Workout)
    mealsButton.grid(row=6, column=0, columnspan=10, rowspan=2)
    profileButton = customtkinter.CTkButton(Home, text="Profile", command = Workout)
    profileButton.grid(row=8, column=0, columnspan=10, rowspan=2)

def VerifyBack():
    middlePage.destroy()
    root.deiconify()

def HomeBack():
    Home.destroy()
    root.deiconify()

def RegisterBack():
    RegisterPage.destroy()
    root.deiconify()

def WorkoutBack():
    WorkoutPage.destroy()
    HomeWindow()

#==============================VARIABLES======================================
USERNAME = StringVar()
PASSWORD = StringVar()
CODE = StringVar()

#==============================FRAMES=========================================
Top = customtkinter.CTkFrame(root)
Top.pack(side=TOP, fill=X)
Form = customtkinter.CTkFrame(root, height=200)
Form.pack(side=TOP, pady=20)

#==============================LABELS=========================================
labelTitle = customtkinter.CTkLabel(Top, text = "Workout App", font=('arial', 15))
labelTitle.pack(fill=X)
labelUsername = customtkinter.CTkLabel(Form, text= "Username:", font=('arial', 14))
labelUsername.grid(row=0, sticky="e")
labelPassword = customtkinter.CTkLabel(Form, text= "Password:", font=('arial', 14))
labelPassword.grid(row=1, sticky="e")
labelText = customtkinter.CTkLabel(Form, text = "")
labelText.grid(row=2, columnspan=2)

#==============================ENTRY WIDGETS==================================
username = Entry(Form, textvariable=USERNAME, font=(14))
username.grid(row=0, column=1)
password = Entry(Form, textvariable=PASSWORD, show="*", font=(14))
password.grid(row=1, column=1)

#==============================BUTTON WIDGETS=================================
loginButton = customtkinter.CTkButton(Form, text="Login", width=45, command=Login)
loginButton.grid(pady=25, row=3, columnspan=2)
loginButton.bind('<Return>', Login)
registerButton = customtkinter.CTkButton(Form, text="Register", width=45, command=Register)
registerButton.grid(pady=25, row=4, columnspan=2)

#==============================INITIALIATION==================================
if __name__ == '__main__':
    root.mainloop()